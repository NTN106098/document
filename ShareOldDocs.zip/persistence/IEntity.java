package com.axonactive.jpa.persistence;

public interface IEntity {

	int getId();
}
